package com.org.git;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class GitTest {
	
	String sSHKey = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCdyIm/1Gh9I6M4vNg1MN06aAcZK6hNp7DnalIJ89fR7fpVQSvX7Ai4ZSZZNjYHWjLDr6bPX1yx6PvYDdW34GNuQcoBvF/xYkV5rJO7Q5vTZieKaNAoQsi/3AvXOUtTMluZzbIkONejuR93qIzHUU/F9T2sr2HdsKBf2Vaks0iz/mLmAC8vKzrUZxPjjy/y0gBPqUMfxjCcV27A5HnfatOsY1evhmt0bwhTZeD0KlKqsnLFCK5cqsuEgoyjBXW8Rj7OkQ2kNZHqJ7Q0SIJW91Q7ItBYUzz2DRt2Q0abusTp09VElB+UafDamO9xSYQTw14yeGr8QPopvWKy1TmwzzVBeGmgzSQLv3dWc2MwKVGKjQ4Ccftb4AzLFktjIMsKyI0tLTtIsStv/dvXrQyaaAlQylBWGL1y2jQ1DGgT4iT5KbJvnfDAlUYn59+b7n8E8pippSH+qV3tqjSgGu7cawEMdvim1AQhGEKSAhgqRTA4g3sDaQ9qYAe6x35LIRunUfU";
	int id;
	
	RequestSpecification reqspec;
	ResponseSpecification resspec;
	
	@BeforeClass
	public void setUp() {
		
		reqspec = new RequestSpecBuilder()
				.setContentType(ContentType.JSON)
				.addHeader("Authorization","token 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")
				.setBaseUri("https://api.github.com")
				.build();
	}
	
	@Test(priority=1)
    public void addSSLKey() {
		
		String reqBody = "{\"title\" : \"B7-m2-test\", \"key\" : \""+ sSHKey + "\" }";
		
		Response response = 
				given().contentType(ContentType.JSON).
				body(reqBody).
				when().post("/user/keys");
		
		String resbody = response.thenReturn().asPrettyString();
		System.out.println(resbody);
		System.out.println(response.getStatusCode());
		id = response.then().extract().path("id");
		
		response.then().statusCode(200);
	   
   }
	
	@Test(priority=2)
	public void deleteSSLKey() {
		Response response = given().spec(reqspec).
				pathParam("keyId", sSHKey).
				when().delete("/user/keys/{id}");
		
		String resbody = response.thenReturn().asPrettyString();
		System.out.println(resbody);
		
		response.then().statusCode(204);
		
	}
}
